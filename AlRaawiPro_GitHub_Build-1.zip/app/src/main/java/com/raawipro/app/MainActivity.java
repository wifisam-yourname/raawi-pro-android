package com.raawipro.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private Button offlineButton, onlineButton;
    private boolean onlineMode = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,60,45));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(6), dp(8), dp(6));
        bar.setBackgroundColor(Color.rgb(18,60,45));

        TextView title = new TextView(this);
        title.setText("الرعوي برو");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(6), 0, dp(8), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        offlineButton = makeButton("بدون إنترنت");
        onlineButton = makeButton("بالإنترنت");
        bar.addView(offlineButton, new LinearLayout.LayoutParams(dp(112), dp(42)));
        bar.addView(onlineButton, new LinearLayout.LayoutParams(dp(100), dp(42)));

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setBackgroundColor(Color.WHITE);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (!onlineMode && (url.startsWith("https://") || url.startsWith("http://"))) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);

        offlineButton.setOnClickListener(v -> setMode(false));
        onlineButton.setOnClickListener(v -> setMode(true));
        setMode(false);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setPadding(dp(2), 0, dp(2), 0);
        return b;
    }

    private void setMode(boolean online) {
        onlineMode = online;
        offlineButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                online ? Color.rgb(44,82,67) : Color.rgb(28,145,93)));
        onlineButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                online ? Color.rgb(28,145,93) : Color.rgb(44,82,67)));
        offlineButton.setTextColor(Color.WHITE);
        onlineButton.setTextColor(Color.WHITE);
        Toast.makeText(this, online
                ? "تم تفعيل وضع الإنترنت"
                : "تم تفعيل وضع عدم الاتصال؛ البيانات محفوظة على الهاتف",
                Toast.LENGTH_SHORT).show();
        if (webView != null) webView.reload();
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
