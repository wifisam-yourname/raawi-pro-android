plugins {
    id("com.android.application")
}

android {
    namespace = "com.raawipro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.raawipro.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
